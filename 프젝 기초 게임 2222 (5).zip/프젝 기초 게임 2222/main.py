import sys
from PyQt6.QtWidgets import QApplication
from gui.main_window import DungeonEscapeGameWindow
from gui.background_panel import BackgroundPanel


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = DungeonEscapeGameWindow()
    window.show()
    sys.exit(app.exec())  # PyQt6는 exec()!
