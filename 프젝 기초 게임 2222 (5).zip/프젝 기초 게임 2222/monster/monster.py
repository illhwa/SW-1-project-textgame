class Monster:
    def __init__(self, name, hp, attack, defense, description, rarity="normal", image_path=""):
        self.name = name
        self.hp = hp
        self.max_hp = hp  # 체력 표시용
        self.attack = attack
        self.defense = defense
        self.description = description
        self.rarity = rarity
        self.defeated = False  # 기본값은 False
        self.image_path = image_path  # 몬스터의 이미지 경로

    def is_alive(self):
        return self.hp > 0

    def take_damage(self, damage):
        actual_damage = max(damage - self.defense, 0)
        self.hp -= actual_damage
        return actual_damage
