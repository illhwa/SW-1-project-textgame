from monster.monster import Monster
import random

class MonsterManager:
    def __init__(self):
        self.monster_data = [
            # ✅ 일반 몬스터
            {"name": "해골병사", "hp": 50, "attack": 10, "defense": 5, "description": "부서진 갑옷을 걸친 해골병사", "rarity": "normal", "image_path":"assets/images/monsters/skeleton_soldier.png"},
            {"name": "동굴 거미", "hp": 40, "attack": 12, "defense": 3, "description": "날렵하고 독이 있는 거미", "rarity": "normal"},
            {"name": "심연의 슬라임", "hp": 60, "attack": 8, "defense": 10, "description": "심연에서 올라온 거대한 슬라임", "rarity": "normal"},
            {"name": "고블린", "hp": 30, "attack": 15, "defense": 2, "description": "작지만 날쌘 고블린", "rarity": "normal"},

            # ✅ 레어 몬스터
            {"name": "탐욕의 망령", "hp": 100, "attack": 20, "defense": 10, "description": "금화에 묻힌 탐욕스러운 망령", "rarity": "rare"},
            {"name": "피에 젖은 기사", "hp": 120, "attack": 25, "defense": 15, "description": "붉게 물든 갑옷을 입은 저주받은 기사", "rarity": "rare"},
            {"name": "그림자 도적", "hp": 80, "attack": 30, "defense": 5, "description": "그림자 속에 숨어 공격하는 도적", "rarity": "rare"},
            {"name": "불길한 눈", "hp": 90, "attack": 18, "defense": 8, "description": "사악한 시선을 보내는 부유하는 눈알", "rarity": "rare"},

            # ✅ 보스 몬스터
            {"name": "고블린 왕", "hp": 300, "attack": 40, "defense": 20, "description": "고블린 무리를 지휘하는 왕", "rarity": "boss"},
            {"name": "켄타우로스 벨카리온", "hp": 400, "attack": 50, "defense": 25, "description": "전설 속의 전쟁광 켄타우로스", "rarity": "boss"},
            {"name": "사이클롭스 카르그", "hp": 500, "attack": 55, "defense": 30, "description": "한 눈으로 모든 것을 꿰뚫는 거인", "rarity": "boss"},
            {"name": "흑마법사 발타자르", "hp": 600, "attack": 70, "defense": 40, "description": "심연의 마력을 다루는 흑마법사", "rarity": "boss"},
        ]

    def get_random_monster(self, rarity="normal"):
        filtered = [m for m in self.monster_data if m["rarity"] == rarity]
        monster_dict = random.choice(filtered)
        return Monster(**monster_dict)

    def get_boss(self, boss_name):
        for m in self.monster_data:
            if m["rarity"] == "boss" and m["name"] == boss_name:
                return Monster(**m)
        return None
