import random
from dungeon.room import Room

class DungeonFloor:
    def __init__(self, floor_number, width=5, height=5, max_rooms=10):
        self.floor_number = floor_number
        self.width = width
        self.height = height
        self.rooms = {}
        self.start_room = None
        self.boss_room = None
        self.max_rooms = max_rooms  # 만들 방 개수 제한

        self.generate_floor()

    def generate_floor(self):
        print(f"\n🚪 {self.floor_number}층 던전 생성 중...")
        self.generate_rooms()
        self.assign_room_types()

    def generate_rooms(self):
        visited = set()
        room_id_counter = 0
        stack = []

        # 시작 방 생성 (0,0 기준)
        x, y = self.width // 2, self.height // 2
        room = Room(room_id=room_id_counter)
        room.x, room.y = x, y
        self.rooms[(x, y)] = room
        self.start_room = room

        stack.append((x, y))
        visited.add((x, y))

        while len(self.rooms) < self.max_rooms and stack:
            cx, cy = stack.pop()
            directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
            random.shuffle(directions)

            for dx, dy in directions:
                nx, ny = cx + dx, cy + dy

                if (nx, ny) in visited:
                    continue
                if len(self.rooms) >= self.max_rooms:
                    break
                if not (0 <= nx < self.width and 0 <= ny < self.height):
                    continue

                # 방 생성
                room_id_counter += 1
                new_room = Room(room_id=room_id_counter)
                new_room.x, new_room.y = nx, ny

                # 연결
                current_room = self.rooms[(cx, cy)]
                current_room.connect(new_room)

                self.rooms[(nx, ny)] = new_room
                visited.add((nx, ny))
                stack.append((nx, ny))

    def assign_room_types(self):
        all_rooms = list(self.rooms.values())

        self.start_room.room_type = "start"
        self.start_room.description = "던전 시작 지점입니다."

        # 보스 방은 가장 먼 방
        self.boss_room = self.find_furthest_room(self.start_room)
        self.boss_room.room_type = "boss"
        self.boss_room.description = "보스가 기다리고 있다..."

        remaining_rooms = [
            room for room in all_rooms
            if room not in [self.start_room, self.boss_room]
        ]

        shop_rooms = random.sample(remaining_rooms, min(2, len(remaining_rooms)))
        for room in shop_rooms:
            room.room_type = "shop"

        remaining_rooms = [r for r in remaining_rooms if r not in shop_rooms]

        rest_rooms = random.sample(remaining_rooms, min(2, len(remaining_rooms)))
        for room in rest_rooms:
            room.room_type = "rest"

        remaining_rooms = [r for r in remaining_rooms if r not in rest_rooms]

        event_rooms = random.sample(remaining_rooms, min(3, len(remaining_rooms)))
        for room in event_rooms:
            room.room_type = "event"

        remaining_rooms = [r for r in remaining_rooms if r not in event_rooms]

        for room in remaining_rooms:
            room.room_type = "monster"
            room.spawn_monster(floor_number=self.floor_number)

    def find_furthest_room(self, start_room):
        max_distance = -1
        furthest_room = None
        for room in self.rooms.values():
            distance = self.manhattan_distance(start_room, room)
            if distance > max_distance:
                max_distance = distance
                furthest_room = room
        return furthest_room

    def manhattan_distance(self, room1, room2):
        return abs(room1.x - room2.x) + abs(room1.y - room2.y)

    def get_room(self, room_id):
        """room_id 기준으로 검색"""
        for room in self.rooms.values():
            if room.room_id == room_id:
                return room
        return None

    def find_room_coords(self, room_id):
        room = self.get_room(room_id)
        if room:
            return (room.y, room.x)
        return None
