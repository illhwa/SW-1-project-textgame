class Monster:
    def __init__(self, name, hp, attack_power):
        self.name = name
        self.hp = hp
        self.attack_power = attack_power

    def take_damage(self, damage):
        self.hp -= damage
        if self.hp < 0:
            self.hp = 0

    def is_dead(self):
        return self.hp <= 0

    def __repr__(self):
        return f"<Monster {self.name} | HP: {self.hp} | ATK: {self.attack_power}>"

