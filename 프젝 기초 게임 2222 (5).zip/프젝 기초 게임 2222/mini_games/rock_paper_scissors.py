from PyQt6.QtWidgets import QWidget, QVBoxLayout, QPushButton, QLabel
from PyQt6.QtCore import QTimer
import random

class RockPaperScissorsGame(QWidget):
    def __init__(self, finish_callback):
        super().__init__()
        self.finish_callback = finish_callback
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        self.label = QLabel("가위, 바위, 보 중 선택하세요!")
        layout.addWidget(self.label)

        btn_rock = QPushButton("가위")
        btn_rock.clicked.connect(lambda: self.play(0))
        layout.addWidget(btn_rock)

        btn_paper = QPushButton("바위")
        btn_paper.clicked.connect(lambda: self.play(1))
        layout.addWidget(btn_paper)

        btn_scissors = QPushButton("보")
        btn_scissors.clicked.connect(lambda: self.play(2))
        layout.addWidget(btn_scissors)

    def play(self, player_choice):
        computer_choice = random.randint(0, 2)

        if player_choice == computer_choice:
            self.label.setText("비겼습니다! 다시 도전!")
            return

        win_conditions = {(0, 2), (1, 0), (2, 1)}

        if (player_choice, computer_choice) in win_conditions:
            self.label.setText("승리했습니다!")
            success = True
        else:
            self.label.setText("패배했습니다!")
            success = False

        QTimer.singleShot(1000, lambda: self.finish(success))

    def finish(self, success):
        self.finish_callback(success)
