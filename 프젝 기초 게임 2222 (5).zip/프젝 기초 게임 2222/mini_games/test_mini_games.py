from rock_paper_scissors import RockPaperScissorsGame
from dice_odd_even import DiceOddEven
from timing_game import TimingGame
from key_input_game import KeyInputGame

class DummyPlayer:
    def __init__(self):
        self.luck = 10

def test_rock_paper_scissors():
    player = DummyPlayer()
    game = RockPaperScissorsGame(player)1
    print(f"\n🎮 {game.name} 테스트 시작!")
    result = game.play()
    print("결과:", "성공!" if result else "실패!")

def test_dice_odd_even():
    player = DummyPlayer()
    game = DiceOddEven(player)
    print(f"\n🎮 {game.name} 테스트 시작!")
    result = game.play()
    print("결과:", "성공!" if result else "실패!")

def test_timing_game():
    player = DummyPlayer()
    game = TimingGame(player)
    print(f"\n🎮 {game.name} 테스트 시작!")
    result = game.play()
    print("결과:", "성공!" if result else "실패!")

def test_key_input_game():
    player = DummyPlayer()
    game = KeyInputGame(player)
    print(f"\n🎮 {game.name} 테스트 시작!")
    result = game.play()
    print("결과:", "성공!" if result else "실패!")

def run():
    while True:
        print("\n=== 미니게임 테스트 ===")
        print("1. 가위바위보 테스트")
        print("2. 주사위 홀짝 테스트")
        print("3. 타이밍 게임 테스트")
        print("4. 키 입력 반응 게임 테스트")
        print("0. 종료")

        choice = input("번호를 선택하세요: ")
        if choice == "1":
            test_rock_paper_scissors()
        elif choice == "2":
            test_dice_odd_even()
        elif choice == "3":
            test_timing_game()
        elif choice == "4":
            test_key_input_game()
        elif choice == "0":
            print("테스트 종료!")
            break
        else:
            print("잘못된 입력입니다!")

if __name__ == "__main__":
    run()

