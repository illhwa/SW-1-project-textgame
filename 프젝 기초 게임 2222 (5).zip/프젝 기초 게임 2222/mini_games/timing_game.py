from PyQt6.QtWidgets import QWidget, QVBoxLayout, QPushButton, QLabel
from PyQt6.QtCore import QTimer
import random
import time

class TimingGame(QWidget):
    def __init__(self, finish_callback):
        super().__init__()
        self.finish_callback = finish_callback
        self.init_ui()

    def init_ui(self):
        self.layout = QVBoxLayout(self)

        self.label = QLabel("타이밍에 맞게 클릭하세요!")
        self.layout.addWidget(self.label)

        self.button = QPushButton("클릭!")
        self.button.setEnabled(False)
        self.button.clicked.connect(self.success)
        self.layout.addWidget(self.button)

        delay = random.randint(1000, 3000)
        QTimer.singleShot(delay, self.activate_button)

    def activate_button(self):
        self.label.setText("지금!")
        self.button.setEnabled(True)
        self.start_time = time.time()

        # 자동 실패 타이머
        QTimer.singleShot(2000, self.fail_if_no_action)

    def success(self):
        elapsed = time.time() - self.start_time
        if elapsed <= 2:
            self.label.setText(f"성공! 반응 시간: {elapsed:.2f}초")
            QTimer.singleShot(1000, lambda: self.finish(True))
        else:
            self.fail()

    def fail_if_no_action(self):
        if self.button.isEnabled():
            self.fail()

    def fail(self):
        self.label.setText("실패! 너무 늦었어요.")
        QTimer.singleShot(1000, lambda: self.finish(False))

    def finish(self, success):
        self.finish_callback(success)
