from player.player import Player
from inventory.item_manager import ItemManager
from dungeon.dungeon import Dungeon

class GameManager:
    def __init__(self):
        self.player = Player("주인공")
        self.item_manager = ItemManager()
        self.dungeon = Dungeon(self.player, self.item_manager)
