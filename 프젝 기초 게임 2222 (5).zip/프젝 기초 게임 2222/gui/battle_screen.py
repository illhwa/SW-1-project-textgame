from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton
from PyQt6.QtCore import Qt
from mini_games.rock_paper_scissors import RockPaperScissorsGame

class BattleScreen(QWidget):
    def __init__(self, parent, game_manager):
        super().__init__()
        self.parent = parent
        self.game_manager = game_manager

        self.layout = QVBoxLayout()
        self.setLayout(self.layout)

    def set_monster(self, monster):
        self.monster = monster
        self.clear_layout()

        self.status_label = QLabel()
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.start_game_button = QPushButton("가위바위보 시작")
        self.start_game_button.clicked.connect(self.start_minigame)

        self.layout.addWidget(self.status_label)
        self.layout.addWidget(self.start_game_button)

        self.update_status()

    def clear_layout(self):
        # 기존 위젯 제거
        while self.layout.count():
            item = self.layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

    def update_status(self):
        player = self.game_manager.player
        self.status_label.setText(
            f"[몬스터] {self.monster.name} HP: {self.monster.hp}/{self.monster.max_hp}\n"
            f"[플레이어] HP: {player._hp}/{player._max_hp}"
        )

    def start_minigame(self):
        # 가위바위보 미니게임 위젯 생성
        self.rps_game = RockPaperScissorsGame(self, self.game_manager.player, self.monster)
        self.layout.addWidget(self.rps_game)

    def finish_battle(self, win):
        if win:
            self.parent.stack.setCurrentIndex(1)  # 던전으로 복귀
        else:
            self.parent.stack.setCurrentIndex(0)  # 메인메뉴로 복귀 (패배 처리)
