from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QStackedWidget, QInputDialog, QFrame
)
from PyQt6.QtGui import QPixmap, QPainter
from PyQt6.QtCore import Qt,QPropertyAnimation, QPoint, QEasingCurve


from dungeon.dungeon_floor import DungeonFloor
from gui.minimap_widget import MiniMapWidget
from gui.inventory_window import InventoryWindow
from gui.shop_window import ShopWindow
from combat.combat_manager import CombatManager
from player.player import Player
from item.item_manager import ItemManager
from gui.background_panel import BackgroundPanel
from gui.dungeon_intro import IntroOverlay
from monster.monster import Monster
IMAGE_PATHS = {
    "dungeon_bg": "assets/backgrounds/dungeon_bg.png"
}

class DungeonEscapeGameWindow(QMainWindow):
    def __init__(self):  
        super().__init__()


        self.setWindowTitle("던전 탈출 로그라이크 (PyQt6)")
        self.setGeometry(100, 100, 1000, 600)

        # ✅ 배경 이미지 미리 로드
        self.bg_pixmap = QPixmap(IMAGE_PATHS["dungeon_bg"])

        # ✅ item_manager 인스턴스 생성
        self.item_manager = ItemManager()

        # ✅ 기본 스택 생성 및 화면 준비
        self.stack = QStackedWidget()
        self.setCentralWidget(self.stack)

        # ✅ 기본 UI 세팅 (메인 플레이 화면 틀)
        self.setup_game_ui()

        # ✅ 인트로 오버레이 띄우고 끝난 후 던전 진입!
        self.intro_overlay = IntroOverlay(self, self.start_new_game)
        self.intro_overlay.show()

  # 몬스터 이미지 표시용 QLabel
        self.monster_image_label = QLabel(self)
        self.monster_image_label.setGeometry(250, 200, 200, 200)  # 위치 및 크기 설정
        
        # 예시로 해골 병사 몬스터 생성
        self.skeleton_soldier = Monster(
            name="Skeleton Soldier", 
            hp=150, 
            attack=20, 
            defense=10, 
            description="A fearsome skeleton soldier.",
            rarity="normal",
            image_path="assets/monster/skeleton_soldiers.png"  # 해골 병사 이미지 경로
        )

        # 몬스터 등장
        self.show_monster(self.skeleton_soldier)



    def show_monster(self, monster):
        """몬스터 이미지를 메인 윈도우에 표시하는 메서드"""
        if monster.image_path:
            pixmap = QPixmap(monster.image_path)
            self.monster_image_label.setPixmap(pixmap)
            self.monster_image_label.setScaledContents(True)  # 이미지 크기 자동 조정
            self.monster_image_label.show()  # QLabel을 화면에 띄우기


    def setup_game_ui(self):
        self.main_ui = QWidget()
        self.main_layout = QHBoxLayout(self.main_ui)


    def paintEvent(self, event):
        # ✅ 왼쪽과 중앙에만 배경 적용
        painter = QPainter(self)
        if not self.bg_pixmap.isNull():
            # 전체 윈도우 크기에 맞춰 배경 이미지 스케일
            scaled_bg = self.bg_pixmap.scaled(
                self.size(),
                Qt.AspectRatioMode.IgnoreAspectRatio,
                Qt.TransformationMode.SmoothTransformation
            )
            painter.drawPixmap(0, 0, scaled_bg)
        super().paintEvent(event)

    def start_new_game(self):
        player_name, ok = QInputDialog.getText(self, "플레이어 이름", "닉네임을 입력하세요:")
        if ok and player_name:
            self.player = Player(player_name)
        else:
            self.player = Player("이름없는 모험가")

        self.current_monster = None
        self.combat_manager = None


        # 던전 초기화
        self.current_floor = DungeonFloor(floor_number=1)
        self.current_room_id = self.current_floor.start_room.room_id

        # 메인 UI 생성
        self.main_ui = QWidget()
        self.main_layout = QHBoxLayout(self.main_ui)


        # 3. 왼쪽 패널 세팅
        self.left_panel = BackgroundPanel(IMAGE_PATHS["dungeon_bg"])
        left_panel_layout = self.left_panel.layout

        self.map_ui = MiniMapWidget(self.current_floor, self.current_room_id)
        left_panel_layout.addWidget(self.map_ui)

        self.description_label = QLabel("던전 탐험을 시작합니다!")
        self.description_label.setStyleSheet("color: white; font-weight: bold; padding: 5px;")
        left_panel_layout.addWidget(self.description_label)

        self.choice_buttons_layout = QVBoxLayout()
        left_panel_layout.addLayout(self.choice_buttons_layout)

        # 4. 오른쪽 패널 세팅
        right_panel = QFrame()
        right_panel.setStyleSheet("background-color: rgba(255, 255, 255, 0.9); border-radius: 10px;")
        right_layout = QVBoxLayout(right_panel)

        right_layout.addWidget(QLabel("🎮 상태 패널"))

        self.status_label = QLabel()
        right_layout.addWidget(self.status_label)

        self.monster_status_label = QLabel()
        right_layout.addWidget(self.monster_status_label)

        right_layout.addWidget(QLabel("🎒 인벤토리"))
        self.inventory_label = QLabel()
        self.inventory_label.setTextFormat(Qt.TextFormat.RichText)
        right_layout.addWidget(self.inventory_label)

        right_layout.addWidget(QLabel("🛡️ 장착 아이템"))
        self.equipped_label = QLabel()
        self.equipped_label.setTextFormat(Qt.TextFormat.RichText)
        right_layout.addWidget(self.equipped_label)

        open_inventory_btn = QPushButton("🎒 인벤토리 열기")
        open_inventory_btn.clicked.connect(self.open_inventory_window)
        right_layout.addWidget(open_inventory_btn)

        # 5. 메인 레이아웃 완성
        self.main_layout.addWidget(self.left_panel, 3)
        self.main_layout.addWidget(right_panel, 1)

        # 6. UI 적용
        self.main_ui.setLayout(self.main_layout)
        self.stack.addWidget(self.main_ui)
        self.stack.setCurrentWidget(self.main_ui)

        # 7. 탐험 시작
        self.enter_room(self.current_room_id)





    def open_inventory_window(self):
        self.inventory_window = InventoryWindow(self.player, self)
        self.inventory_window.show()

    def open_shop_window(self):
        self.shop_window = ShopWindow(self.player, self.item_manager, self)
        self.shop_window.show()

    def enter_room(self, room_id):
        room = self.current_floor.get_room(room_id)
        self.current_room_id = room_id

        room.visited = True
        room.revealed = True
        self.map_ui.update_current_room(room_id)

         # ✅ 이동 애니메이션 실행
        self.play_walk_animation()

        self.description_label.setText(f"{room.room_type.upper()} 방입니다.\n{room.description}")
        self.update_choices()

        if room.room_type == "monster" and not room.monster.defeated:
            self.start_combat(room.monster)
        
        elif room.is_boss_room:
            self.start_boss_battle()    

        elif room.room_type == "event":
            if not hasattr(room, "event_completed") or not room.event_completed:
                item = self.item_manager.get_random_item()
                self.player.add_item(item)
                room.event_completed = True
                self.update_description(f"📦 보물상자를 열어 '{item.name}'을(를) 획득했습니다!")
            else:
                self.update_description("이미 탐색한 이벤트 방입니다.")

        elif room.room_type == "shop":
            if not hasattr(room, "shop_completed") or not room.shop_completed:
                self.open_shop_window()
                room.shop_completed = True
            else:
                self.update_description("이미 방문한 상점입니다.")

        elif room.room_type == "rest":
            if not hasattr(room, "rest_completed") or not room.rest_completed:
                self.enter_rest_area()
                room.rest_completed = True
            else:
                self.update_description("이미 휴식을 취한 쉼터입니다.")

        else:
            self.current_monster = None

        self.update_status()

    def start_boss_battle(self):
        # 층수에 따라 보스 이름 결정 (예시)
        boss_names = [
            "고블린 왕",
            "켄타우로스 벨카리온",
            "사이클롭스 카르그",
            "흑마법사 발타자르"
        ]

        # 현재 층에 맞는 보스 선택
        floor_index = self.current_floor.floor_number - 1
        boss_name = boss_names[floor_index]

        # 보스 소환
        boss_monster = self.monster_manager.get_boss(boss_name)

        # 전투 시작
        self.combat_manager.start_combat(self.player, boss_monster)
        
        # 설명 출력 (GUI 업데이트)
        self.description_label.setText(f"보스룸에 입장했습니다! {boss_monster.name}이(가) 나타났다!")

    def enter_rest_area(self):
        self.update_description("😴 쉼터에 도착했습니다. 무엇을 할까요?")
        self.clear_choice_buttons()

        heal_btn = QPushButton("❤️ 체력 회복하기")
        heal_btn.clicked.connect(self.rest_heal)
        self.choice_buttons_layout.addWidget(heal_btn)

        boost_btn = QPushButton("💪 능력치 강화하기")
        boost_btn.clicked.connect(self.rest_boost_stats)
        self.choice_buttons_layout.addWidget(boost_btn)

        self.add_room_move_buttons()

    def rest_heal(self):
        heal_amount = int(self.player._max_hp * 0.2)
        if self.player._hp >= self.player._max_hp:
            self.update_description("이미 체력이 가득 찼습니다!")
            return

        self.player._hp += heal_amount
        if self.player._hp > self.player._max_hp:
            self.player._hp = self.player._max_hp

        self.update_description(f"❤️ 체력을 {heal_amount} 회복했습니다!")
        self.update_status()

    def rest_boost_stats(self):
        stat_list = ["luck", "stamina", "hp"]
        stat_name, ok = QInputDialog.getItem(self, "능력치 강화", "어떤 능력치를 강화할까요?", stat_list, editable=False)

        if ok and stat_name:
            self.player.strengthen_stat(stat_name, 5)
            self.update_description(f"✅ {stat_name.upper()}가 5 증가했습니다!")
            self.update_status()

    def add_room_move_buttons(self):
        current_room = self.current_floor.get_room(self.current_room_id)
        current_coords = self.current_floor.find_room_coords(self.current_room_id)

        for neighbor_id in current_room.connected_rooms:
            neighbor_coords = self.current_floor.find_room_coords(neighbor_id)
            direction = self.get_direction(current_coords, neighbor_coords)

            btn = QPushButton(f"{direction} 이동")
            btn.clicked.connect(lambda checked, rid=neighbor_id: self.enter_room(rid))
            self.choice_buttons_layout.addWidget(btn)

    def clear_choice_buttons(self):
        while self.choice_buttons_layout.count():
            item = self.choice_buttons_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()

    def start_combat(self, monster):
        self.current_monster = monster
        self.combat_manager = CombatManager(self.player, monster, self, self.item_manager)
        self.update_status()

    def update_choices(self):
        if self.current_monster:
            return
        self.clear_choice_buttons()

        current_room = self.current_floor.get_room(self.current_room_id)
        current_coords = self.current_floor.find_room_coords(self.current_room_id)

        for neighbor_id in current_room.connected_rooms:
            neighbor_coords = self.current_floor.find_room_coords(neighbor_id)
            direction = self.get_direction(current_coords, neighbor_coords)

            btn = QPushButton(f"{direction} 이동")
            btn.clicked.connect(lambda checked, rid=neighbor_id: self.enter_room(rid))
            self.choice_buttons_layout.addWidget(btn)

    def get_direction(self, current_coords, target_coords):
        cy, cx = current_coords
        ty, tx = target_coords

        if cy == ty:
            return "오른쪽으로" if cx < tx else "왼쪽으로"
        elif cx == tx:
            return "아래로" if cy < ty else "위로"
        return "알 수 없음"

    def update_description(self, text):
        self.description_label.setText(text)
        self.update_status()

    def update_status(self):
        player_status_text = (
            f"🧙‍♂️ 이름: {self.player._name}\n"
            f"❤️ HP: {self.player.hp} / {self.player._max_hp}\n"
            f"⚡ 스태미나: {self.player._stamina}\n"
            f"🍀 운: {self.player._luck}\n"
            f"💰 골드: {self.player.currency}\n"
        )
        self.status_label.setText(player_status_text)

        if self.current_monster:
            monster_status_text = (
                f"👾 몬스터: {self.current_monster.name}\n"
                f"❤️ HP: {self.current_monster.hp}\n"
                f"⚔️ 공격력: {self.current_monster.attack}\n"
            )
        else:
            monster_status_text = "👾 몬스터 없음"
        self.monster_status_label.setText(monster_status_text)

        inventory_html = "<b>보유 아이템:</b><br>"
        for idx, item in enumerate(self.player.get_inventory(), 1):
            inventory_html += f"{idx}. {item.get_colored_name()}<br>"
        self.inventory_label.setText(inventory_html)

        equipped_html = "<b>장착 아이템:</b><br>"
        for slot, item in self.player.get_equipped().items():
            if item:
                equipped_html += f"{slot.capitalize()}: {item.get_colored_name()}<br>"
            else:
                equipped_html += f"{slot.capitalize()}: 없음<br>"
        self.equipped_label.setText(equipped_html)

    def play_walk_animation(self):
        # 흔들릴 위젯 (left_panel 또는 center_widget)
        target_widget = self.left_panel  # ← 네가 선언한 패널 이름 맞춰줘야 함!

        # 애니메이션 인스턴스 생성
        animation = QPropertyAnimation(target_widget, b"pos")
        animation.setDuration(200)  # 총 0.2초 안에 흔들리게

        # 현재 위치 기준으로 살짝 이동
        current_pos = target_widget.pos()
        offset = 5  # 몇 픽셀 움직일지 (더 작게 조정 가능)

        # 왔다 갔다 위치 지정
        animation.setKeyValueAt(0, current_pos)
        animation.setKeyValueAt(0.25, current_pos + QPoint(-offset, 0))  # 왼쪽으로 이동
        animation.setKeyValueAt(0.5, current_pos + QPoint(offset, 0))    # 오른쪽으로 이동
        animation.setKeyValueAt(0.75, current_pos + QPoint(-offset, 0))  # 다시 왼쪽
        animation.setKeyValueAt(1, current_pos)  # 원위치로 돌아옴

        animation.setEasingCurve(QEasingCurve.Type.Linear)
        animation.start()

        # 객체가 GC에 의해 소멸하지 않도록 인스턴스를 유지!
        self.walk_animation = animation
