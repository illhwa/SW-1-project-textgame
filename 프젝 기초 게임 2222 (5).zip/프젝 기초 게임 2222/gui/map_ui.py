from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton

class MapUI(QWidget):
    def __init__(self, parent, dungeon_floor, move_to_room_callback):
        super().__init__()

        self.parent = parent
        self.dungeon_floor = dungeon_floor
        self.move_to_room_callback = move_to_room_callback

        self.layout = QVBoxLayout()

        self.info_label = QLabel(f"{self.dungeon_floor.floor_level} 층")
        self.layout.addWidget(self.info_label)

        self.room_buttons = []
        self.setLayout(self.layout)

    def update_room_options(self, current_room_id):
        # 기존 버튼 초기화
        for btn in self.room_buttons:
            self.layout.removeWidget(btn)
            btn.deleteLater()

        self.room_buttons = []

        # 연결된 방 표시
        connected_rooms = self.dungeon_floor.get_connected_rooms(current_room_id)
        for room_id in connected_rooms:
            room = self.dungeon_floor.get_room(room_id)
            btn = QPushButton(f"{room.room_type.upper()} 방 이동")
            btn.clicked.connect(lambda checked, rid=room_id: self.move_to_room_callback(rid))
            self.layout.addWidget(btn)
            self.room_buttons.append(btn)

        # 현재 방 설명 표시
        room = self.dungeon_floor.get_room(current_room_id)
        self.info_label.setText(
            f"현재 방: {room.room_type.upper()} / 설명: {room.description}"
        )
