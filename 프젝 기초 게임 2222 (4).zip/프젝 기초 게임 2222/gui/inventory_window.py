from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QListWidget, QListWidgetItem, QMessageBox
from PyQt6.QtCore import Qt

class InventoryWindow(QWidget):
    def __init__(self, player, game_window):
        super().__init__()

        self.player = player
        self.game_window = game_window

        self.setWindowTitle("🎒 인벤토리 관리")
        self.setGeometry(300, 300, 400, 500)

        layout = QVBoxLayout()

        self.item_list = QListWidget()
        layout.addWidget(QLabel("가방 속 아이템 목록"))
        layout.addWidget(self.item_list)

        self.equip_button = QPushButton("장착하기")
        self.equip_button.clicked.connect(self.equip_selected_item)
        layout.addWidget(self.equip_button)

        self.unequip_button = QPushButton("장착 해제하기")
        self.unequip_button.clicked.connect(self.unequip_selected_slot)
        layout.addWidget(self.unequip_button)

        self.setLayout(layout)
        self.refresh_inventory()

    def refresh_inventory(self):
        self.item_list.clear()

        for item in self.player.get_inventory():
            item_str = f"{item.name} [{item.item_type.upper()}] - {item.description}"
            item_widget = QListWidgetItem(item_str)
            item_widget.setData(Qt.ItemDataRole.UserRole, item)
            self.item_list.addItem(item_widget)

    def equip_selected_item(self):
        selected_items = self.item_list.selectedItems()

        if not selected_items:
            QMessageBox.warning(self, "경고", "장착할 아이템을 선택하세요!")
            return

        item = selected_items[0].data(Qt.ItemDataRole.UserRole)

        success = self.player.equip_item(item)
        if success:
            QMessageBox.information(self, "성공", f"{item.name} 장착 완료!")
        else:
            QMessageBox.warning(self, "실패", f"{item.name} 장착 실패!")

        self.refresh_inventory()
        self.game_window.update_status()

    def unequip_selected_slot(self):
        equipped_slots = self.player.get_equipped()

        slot_text = ""
        for slot, item in equipped_slots.items():
            if item:
                slot_text += f"{slot.capitalize()} - {item.name}\n"

        if not slot_text:
            QMessageBox.information(self, "알림", "장착된 아이템이 없습니다!")
            return

        slots = [slot for slot, item in equipped_slots.items() if item]

        # 슬롯 선택 다이얼로그
        from PyQt6.QtWidgets import QInputDialog
        selected_slot, ok = QInputDialog.getItem(
            self,
            "슬롯 선택",
            f"어떤 슬롯의 아이템을 해제할까요?\n\n{slot_text}",
            slots,
            editable=False
        )

        if ok and selected_slot:
            self.player.unequip_item(selected_slot)
            QMessageBox.information(self, "해제 완료", f"{selected_slot.capitalize()} 슬롯이 비워졌습니다.")

        self.refresh_inventory()
        self.game_window.update_status()
