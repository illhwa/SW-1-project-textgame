from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QFont

class EndingTeaser(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("던전 엔딩 티저")
        self.setGeometry(300, 100, 800, 600)
        self.setStyleSheet("background-color: black;")

        self.layout = QVBoxLayout(self)
        self.layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.text_label = QLabel("")
        self.text_label.setStyleSheet("color: white; background-color: rgba(0, 0, 0, 150);")
        self.text_label.setFont(QFont("Arial", 20))
        self.text_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.layout.addWidget(self.text_label)

        # PDF 기반 엔딩 티저 텍스트 (로렌스 배신 엔딩 시나리오)
        self.ending_texts = [
            "던전이 흔들리기 시작했다.",
            "공간이 부서지며 금화 더미가 허물어졌다.",
            "그러나, 그 모든 혼란 속에서도 금은보화는 그대로 남아 있었다.",
            "끝없는 황금빛 바다. 빛나는 보석과 보물. 왕관, 유물, 검, 황금갑옷.",
            "이제, 이 모든 것은 그들의 것이었다.",
            "\"…우리가 이겼군.\" 주인공이 천천히 검을 내려놓았다.",
            "이제 남은 것은 던전에서 탈출하는 것뿐이었다.",
            "그러나.. 그 순간.",
            "스르륵.. 차가운 금속이 살을 가르는 소리. 선혈이 튀었다.",
            "주인공은 가슴에 깊이 박힌 검을 느꼈다.",
            "눈을 크게 뜬 채, 천천히 아래를 내려다보았다.",
            "그리고... 검을 꽂은 자를 보았다.",
            "\"미안하지만, 네 몫까지 나눌 생각은 없어.\"",
            "로렌스는 차갑게 미소 지으며 검을 깊이 밀어 넣었다.",
            "주인공은 고통 속에서 떨리는 목소리로 말했다. \"네가... 왜...\"",
            "그러나, 그의 눈빛에는 일말의 망설임도 없었다.",
            "\"이 보물들은 내 거다. 처음부터, 너 따위와 나눌 생각은 없었어.\"",
            "던전이 무너지는 동안, 그는 주인공을 천천히 구멍속으로 밀어 넘어뜨렸다.",
            "로렌스는 검을 뽑아 피를 털어내며 주인공을 내려다보았다.",
            "\"넌 이곳에서 죽고, 난 바깥세상에서 살아남을 거다.\"",
            "그는 돌아섰다. 그리고, 금화 사이에서 빛나는 왕관을 집어 들었다.",
            "\"...잘 어울리는군.\" 그는 조용히 그것을 머리에 얹었다.",
            "그 순간, 던전이 거세게 흔들리기 시작했다.",
            "출구가 점점 무너져 내렸다. 그는 보물을 가득 품에 안고, 탈출구를 향해 달렸다.",
            "주인공은 마지막 힘을 짜내어 손을 뻗었지만, 그의 몸은 더 이상 움직이지 않았다.",
            "폐허가 된 던전의 입구. 그곳에서, 로렌스는 피로 물든 몸으로 걸어 나왔다.",
            "그리고, 그의 손에는 황금이 가득했다.",
            "그는 천천히 바깥세상을 바라보며 작게 웃음을 지었다.",
            "\"이제, 내 세상이 시작되는군.\"",
            "그리고, 그는 황금빛 왕관을 쓴 채 바깥세상으로 걸어갔다.",
            "그러나, 그가 알지 못하는 것이 있었다.",
            "그가 손에 쥔 보물은... 아직도 흑마법사의 저주를 품고 있었다.",
            "그리고, 그가 이 보물을 쥔 순간부터, 그의 운명은 다시 변하기 시작할 것이다.",
            "The End"
        ]

        self.current_index = 0

        self.start_teaser()

    def start_teaser(self):
        self.show_next_text()

    def show_next_text(self):
        if self.current_index < len(self.ending_texts):
            self.text_label.setText(self.ending_texts[self.current_index])
            self.current_index += 1
            QTimer.singleShot(3000, self.show_next_text)  # 3초 간격
        else:
            self.text_label.setText("The End")

if __name__ == '__main__':
    from PyQt6.QtWidgets import QApplication
    import sys

    app = QApplication(sys.argv)
    teaser = EndingTeaser()
    teaser.show()
    sys.exit(app.exec())
