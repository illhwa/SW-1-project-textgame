from PyQt6.QtWidgets import QWidget, QGridLayout, QLabel
from PyQt6.QtCore import Qt

class MiniMapWidget(QWidget):
    def __init__(self, dungeon_floor, current_room_id):
        super().__init__()

        self.dungeon_floor = dungeon_floor
        self.current_room_id = current_room_id

        self.layout = QGridLayout()
        self.setLayout(self.layout)

        # ✅ 전체 미니맵 크기 설정
        self.setFixedSize(200, 200)
        self.layout.setSpacing(0)

        self.draw_map()

    def draw_map(self):
        # 기존 위젯 초기화
        for i in reversed(range(self.layout.count())):
            widget = self.layout.itemAt(i).widget()
            if widget:
                widget.setParent(None)

        rooms = self.dungeon_floor.rooms.values()
        if not rooms:
            return

        xs = [room.x for room in rooms]
        ys = [room.y for room in rooms]

        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)

        for room in rooms:
            x = room.x - min_x
            y = room.y - min_y

            # 방 라벨
            label = QLabel()
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            label.setFixedSize(20, 20)

            # ✅ 밝혀지지 않은 방
            if not room.revealed:
                label.setText("")
                label.setStyleSheet("background-color: black; border: 1px solid gray;")
            else:
                # ✅ 방 타입별 표시
                text = self.get_room_display(room)
                color = self.get_room_color(room)

                label.setText(text)
                label.setStyleSheet(f"background-color: {color}; border: 1px solid black; font-size: 8px;")

            self.layout.addWidget(label, y * 2, x * 2)

            # ✅ 연결 기호 추가
            for neighbor_id in room.connected_rooms:
                neighbor = self.dungeon_floor.get_room(neighbor_id)
                if not neighbor:
                    continue

                dx = neighbor.x - room.x
                dy = neighbor.y - room.y

                path_label = QLabel()
                path_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
                path_label.setFixedSize(20, 20)
                
                # ✅ 연결선 검은색으로 변경 (기존 white -> black)
                path_label.setStyleSheet("color: black; font-size: 8px;")

                if dx == 1 and dy == 0:
                    self.layout.addWidget(path_label, y * 2, x * 2 + 1)
                    path_label.setText("─")

                elif dx == -1 and dy == 0:
                    self.layout.addWidget(path_label, y * 2, x * 2 - 1)
                    path_label.setText("─")

                elif dx == 0 and dy == 1:
                    self.layout.addWidget(path_label, y * 2 + 1, x * 2)
                    path_label.setText("│")

                elif dx == 0 and dy == -1:
                    self.layout.addWidget(path_label, y * 2 - 1, x * 2)
                    path_label.setText("│")

    def get_room_display(self, room):
        room_type = room.room_type
        if room_type == "start":
            return "S"
        elif room_type == "boss":
            return "B"
        elif room_type == "monster":
            return "M"
        elif room_type == "shop":
            return "$"
        elif room_type == "rest":
            return "R"
        elif room_type == "event":
            return "?"
        return "?"


    def get_room_color(self, room):
        if room.room_id == self.current_room_id:
            return "yellow"
        elif room.room_type == "boss":
            return "red"
        elif room.room_type == "shop":
            return "cyan"
        elif room.room_type == "rest":
            return "green"
        elif room.room_type == "event":
            return "purple"  # ??? 이벤트 방은 보라색으로
        elif room.visited:
            return "white"
        else:
            return "gray"


    def update_current_room(self, current_room_id):
        """현재 방 업데이트 및 인접 방 밝혀주기"""
        self.current_room_id = current_room_id
        room = self.dungeon_floor.get_room(current_room_id)
        room.visited = True
        room.revealed = True

        for neighbor_id in room.connected_rooms:
            neighbor = self.dungeon_floor.get_room(neighbor_id)
            if neighbor:
                neighbor.revealed = True

        self.draw_map()
