import sys
from PyQt6.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QVBoxLayout
from PyQt6.QtCore import Qt, QTimer, QPoint
from PyQt6.QtGui import QPainter, QColor, QPen, QPolygon


class TimingBarGame(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("⭐ 타이밍 바 게임 (가로형)")
        self.setGeometry(600, 300, 600, 300)

        self.bar_x = 100
        self.bar_y = 150
        self.bar_width = 50
        self.bar_height = 20

        self.direction = 1
        self.speed = 6
        self.min_x = 100
        self.max_x = 500

        self.target_x = 300
        self.target_range = 10

        self.timer = QTimer()
        self.timer.timeout.connect(self.update_bar)
        self.timer.start(16)

        self.is_running = True
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        self.result_label = QLabel("타이밍을 맞춰 정지하세요! (스페이스바 가능)")
        self.result_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.stop_button = QPushButton("정지하기")
        self.stop_button.clicked.connect(self.stop_bar)

        layout = QVBoxLayout()
        layout.addWidget(self.result_label)
        layout.addWidget(self.stop_button)
        self.setLayout(layout)

    def update_bar(self):
        if not self.is_running:
            return

        self.bar_x += self.direction * self.speed

        if self.bar_x <= self.min_x or self.bar_x + self.bar_width >= self.max_x:
            self.direction *= -1

        self.update()

    def stop_bar(self):
        if not self.is_running:
            return

        self.is_running = False
        self.timer.stop()

        center_of_bar = self.bar_x + self.bar_width / 2

        if abs(center_of_bar - self.target_x) <= self.target_range:
            result = "🎯 PERFECT!"
        elif abs(center_of_bar - self.target_x) <= self.target_range * 3:
            result = "✅ GOOD!"
        else:
            result = "❌ FAIL!"

        self.result_label.setText(f"{result} (위치: {center_of_bar:.1f})")

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Space:
            self.stop_bar()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # 배경
        painter.setBrush(QColor("#222222"))
        painter.drawRect(self.rect())

        # 타이밍 바
        painter.setBrush(QColor("skyblue"))
        painter.drawRect(int(self.bar_x), self.bar_y, self.bar_width, self.bar_height)

        # 중앙 타겟 화살표
        painter.setBrush(QColor("yellow"))
        arrow_size = 20
        triangle = QPolygon([
            QPoint(self.target_x, self.bar_y - arrow_size),  # 꼭대기
            QPoint(self.target_x - arrow_size // 2, self.bar_y),  # 왼쪽
            QPoint(self.target_x + arrow_size // 2, self.bar_y)   # 오른쪽
        ])
        painter.drawPolygon(triangle)

        # 기준선 (시각 보조용)
        painter.setPen(QPen(QColor("white"), 1, Qt.PenStyle.DashLine))
        painter.drawLine(self.min_x, self.bar_y, self.max_x, self.bar_y)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = TimingBarGame()
    window.show()
    sys.exit(app.exec())
