from managers.battle_manager import BattleManager
from dungeon.room import Room

class Dungeon:
    def __init__(self, player, item_manager):
        self.player = player
        self.item_manager = item_manager
        self.current_room = None
        self.dungeon_floor = None  # 현재 층 정보

    def explore(self):
        print("\n📍 던전을 탐험합니다!")
        while True:
            print(f"현재 방: {self.current_room.room_id} ({self.current_room.room_type})")

            command = input("이동할 방향을 입력하세요 (N/S/E/W), 종료는 Q: ").lower()
            if command == "q":
                print("던전 탐험을 종료합니다.")
                break

            next_room_id = self.choose_next_room(command)
            if next_room_id:
                self.move_to_room(next_room_id)
            else:
                print("이동할 수 없는 방향입니다.")

    def choose_next_room(self, direction):
        # 연결된 방 중에서 방향에 맞는 방 선택 (간단하게 구현)
        if not self.current_room:
            return None
        for neighbor_id in self.current_room.connected_rooms:
            neighbor_room = self.dungeon_floor.get_room(neighbor_id)
            # 방향 로직은 생략하고 무조건 이동 가능으로 처리
            return neighbor_room.room_id
        return None

    def move_to_room(self, room_id):
        room = self.dungeon_floor.get_room(room_id)
        if not room:
            print("존재하지 않는 방입니다.")
            return

        self.current_room = room
        room.visited = True
        print(f"\n🚪 방 {room.room_id}에 입장했습니다. ({room.room_type})")

        # 몬스터 방이면 전투 시작
        if room.room_type == "monster":
            if room.monster is None:
                room.spawn_monster()

            if room.monster and room.monster.hp > 0:
                print(f"⚔️ 몬스터 '{room.monster.name}' 이(가) 출현했다!")
                battle = BattleManager(self.player, room.monster)
                battle.start_battle()

        elif room.room_type == "shop":
            print("🛒 상점에 도착했습니다.")
            # TODO: shop_screen.show()
        elif room.room_type == "rest":
            print("💤 휴식 장소입니다.")
            # TODO: rest_screen.show()
        elif room.room_type == "event":
            print("❓ 이벤트 방입니다.")
            # TODO: event_screen.show()
