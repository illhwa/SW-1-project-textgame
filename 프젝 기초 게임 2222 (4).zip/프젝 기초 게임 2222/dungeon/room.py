from monster.monster import Monster
from monster.monster_manager import MonsterManager

class Room:
    def __init__(self, room_id, room_type="empty", description="", x=0, y=0):
        self.room_id = room_id
        self.room_type = room_type
        self.description = description
        self.connected_rooms = []
        self.revealed = False
        self.visited = False
        self.monster = None
        self.x = x
        self.y = y

        # ✅ 보스룸 여부 추가
        self.is_boss_room = self.room_type == "boss"
        self.monster_manager = MonsterManager()  # 몬스터 매니저 추가

    def connect(self, other_room):
        if other_room.room_id not in self.connected_rooms:
            self.connected_rooms.append(other_room.room_id)
        if self.room_id not in other_room.connected_rooms:
            other_room.connected_rooms.append(self.room_id)

    def spawn_monster(self, floor_number=0):
        if self.is_boss_room and not self.monster:
            boss_names = [
                "고블린 왕",
                "켄타우로스 벨카리온",
                "사이클롭스 카르그",
                "흑마법사 발타자르"
            ]
            index = min(floor_number - 1, len(boss_names) - 1)
            boss_name = boss_names[index]
            self.monster = self.monster_manager.get_boss(boss_name)

        elif self.room_type == "monster" and not self.monster:
            # ✅ 층수에 따라 일반/레어 몬스터를 랜덤으로 가져오기
            if floor_number >= 5:
                self.monster = self.monster_manager.get_random_monster(rarity="rare")
            else:
                self.monster = self.monster_manager.get_random_monster(rarity="normal")
