class Monster:
    def __init__(self, name, hp, attack, defense, description, rarity="normal"):
        self.name = name
        self.hp = hp
        self.max_hp = hp  # 체력 표시용
        self.attack = attack
        self.defense = defense
        self.description = description
        self.rarity = rarity
        self.defeated = False  # ✅ 추가된 속성: 기본값은 False

    def is_alive(self):
        return self.hp > 0

    def take_damage(self, damage):
        actual_damage = max(damage - self.defense, 0)
        self.hp -= actual_damage
        print(f"{self.name}이(가) {actual_damage}의 피해를 입었습니다! 현재 체력: {self.hp}/{self.max_hp}")

        # ✅ 체력이 0 이하일 경우 defeated 상태로 전환
        if self.hp <= 0:
            self.hp = 0
            self.defeated = True
            print(f"{self.name}이(가) 쓰러졌습니다!")
        
        return actual_damage
