from PyQt6.QtWidgets import QWidget, QVBoxLayout, QPushButton, QLabel
from PyQt6.QtCore import QTimer
import random

class DiceOddEven(QWidget):
    def __init__(self, finish_callback):
        super().__init__()
        self.finish_callback = finish_callback
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        self.label = QLabel("주사위 홀/짝 맞히기!")
        layout.addWidget(self.label)

        btn_odd = QPushButton("홀")
        btn_odd.clicked.connect(lambda: self.play('odd'))
        layout.addWidget(btn_odd)

        btn_even = QPushButton("짝")
        btn_even.clicked.connect(lambda: self.play('even'))
        layout.addWidget(btn_even)

    def play(self, player_choice):
        dice = random.randint(1, 6)
        result = 'even' if dice % 2 == 0 else 'odd'

        if player_choice == result:
            self.label.setText(f"주사위: {dice} 🎉 성공!")
            success = True
        else:
            self.label.setText(f"주사위: {dice} 💥 실패!")
            success = False

        QTimer.singleShot(1000, lambda: self.finish(success))

    def finish(self, success):
        self.finish_callback(success)
