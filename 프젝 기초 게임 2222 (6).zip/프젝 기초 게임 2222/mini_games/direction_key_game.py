from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel
from PyQt6.QtCore import Qt, QTimer
import random

class DirectionKeyGame(QWidget):
    def __init__(self, finish_callback):
        super().__init__()
        self.finish_callback = finish_callback
        self.setWindowTitle("🕹️ 방향키 입력 미니게임")
        
        # ✅ 창 크기 조정
        self.setGeometry(300, 300, 400, 300)

        # ✅ 시퀀스와 인덱스 초기화
        self.sequence_length = 8
        self.sequence = self.generate_sequence(self.sequence_length)
        self.current_index = 0

        # ✅ UI 구성
        self.layout = QVBoxLayout()

        self.info_label = QLabel("🕹️ 순서대로 방향키를 입력하세요!")
        self.info_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.info_label.setStyleSheet("font-size: 18px;")
        self.layout.addWidget(self.info_label)

        self.sequence_label = QLabel(self.get_display_sequence())
        self.sequence_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.sequence_label.setStyleSheet("font-size: 24px; font-weight: bold;")
        self.layout.addWidget(self.sequence_label)

        self.timer_label = QLabel("⏱️ 시간: 5")
        self.timer_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.timer_label.setStyleSheet("font-size: 16px;")
        self.layout.addWidget(self.timer_label)

        self.setLayout(self.layout)

        # ✅ 타이머 설정
        self.time_left = 5
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_timer)
        self.timer.start(1000)

        # ✅ 키보드 입력 활성화
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def generate_sequence(self, length):
        directions = ["↑", "↓", "←", "→"]
        return [random.choice(directions) for _ in range(length)]

    def get_display_sequence(self):
        # 남은 방향키 시퀀스를 문자열로 반환
        remaining = self.sequence[self.current_index:]
        return " ".join(remaining)

    def update_timer(self):
        self.time_left -= 1
        self.timer_label.setText(f"⏱️ 시간: {self.time_left}")

        if self.time_left <= 0:
            self.fail_game()

    def keyPressEvent(self, event):
        key_map = {
            Qt.Key.Key_Up: "↑",
            Qt.Key.Key_Down: "↓",
            Qt.Key.Key_Left: "←",
            Qt.Key.Key_Right: "→"
        }

        if event.key() in key_map:
            pressed = key_map[event.key()]
            expected = self.sequence[self.current_index]

            if pressed == expected:
                self.current_index += 1
                self.sequence_label.setText(self.get_display_sequence())

                if self.current_index >= len(self.sequence):
                    self.success_game()
            else:
                self.fail_game()

    def success_game(self):
        self.timer.stop()
        self.info_label.setText("✅ 성공!")
        QTimer.singleShot(1000, lambda: self.finish(True))

    def fail_game(self):
        self.timer.stop()
        self.info_label.setText("❌ 실패!")
        QTimer.singleShot(1000, lambda: self.finish(False))

    def finish(self, success):
        self.finish_callback(success)
        self.close()
