from abc import ABC, abstractmethod

class MiniGame(ABC):
    def __init__(self, player):
        self.player = player

    @abstractmethod
    def play(self):
        pass