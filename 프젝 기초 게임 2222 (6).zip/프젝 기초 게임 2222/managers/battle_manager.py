from mini_games.mini_game_manager import MiniGameManager

class BattleManager:
    def __init__(self, player, monster):
        self.player = player
        self.monster = monster
        self.mini_game_manager = MiniGameManager(player)

    def start_battle(self):
        print(f"⚔️ {self.monster.name} 와의 전투 시작!")

        while self.player.hp > 0 and self.monster.hp > 0:
            print(f"🧙‍♂️ 플레이어 HP: {self.player.hp} | 👾 몬스터 HP: {self.monster.hp}")

            if self.mini_game_manager.play_random_game():
                damage = 10
                self.monster.take_damage(damage)
                print(f"👊 몬스터에게 {damage} 데미지를 입혔습니다!")
            else:
                damage = self.monster.attack_power
                self.player.take_damage(damage)
                print(f"👾 몬스터의 공격! {damage} 데미지를 받았습니다.")

            if self.monster.is_dead():
                print(f"🎉 {self.monster.name} 처치 성공!")
                break
            if self.player.hp <= 0:
                print("☠️ 플레이어가 쓰러졌습니다...")
                break
