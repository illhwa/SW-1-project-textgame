import os
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QStackedWidget, QInputDialog
)
from PyQt6.QtGui import QPixmap, QPainter
from PyQt6.QtCore import Qt

from dungeon.dungeon_floor import DungeonFloor
from gui.minimap_widget import MiniMapWidget
from gui.inventory_window import InventoryWindow
from gui.shop_window import ShopWindow
from combat.combat_manager import CombatManager
from player.player import Player
from item.item_manager import ItemManager
# 절대 경로로 이미지 로드 테스트
absolute_path = os.path.abspath("assets/backgrounds/dungeon_bg.png")
print("절대 경로:", absolute_path)

self.bg_pixmap = QPixmap(absolute_path)
print(self.bg_pixmap.isNull())