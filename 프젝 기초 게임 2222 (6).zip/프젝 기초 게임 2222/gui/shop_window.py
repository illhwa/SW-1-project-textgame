from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QListWidget, QListWidgetItem, QMessageBox
from PyQt6.QtCore import Qt

class ShopWindow(QWidget):
    def __init__(self, player, item_manager, game_window):
        super().__init__()

        self.player = player
        self.item_manager = item_manager
        self.game_window = game_window

        self.setWindowTitle("🏪 상점")
        self.setGeometry(400, 300, 400, 500)

        layout = QVBoxLayout()

        self.shop_list = QListWidget()
        layout.addWidget(QLabel("🛒 구매 가능한 아이템 목록"))
        layout.addWidget(self.shop_list)

        buy_button = QPushButton("구매하기")
        buy_button.clicked.connect(self.buy_selected_item)
        layout.addWidget(buy_button)

        self.inventory_list = QListWidget()
        layout.addWidget(QLabel("🎒 내 인벤토리 (판매 가능)"))
        layout.addWidget(self.inventory_list)

        sell_button = QPushButton("판매하기")
        sell_button.clicked.connect(self.sell_selected_item)
        layout.addWidget(sell_button)

        self.setLayout(layout)

        self.refresh_shop_items()
        self.refresh_inventory_items()

    def refresh_shop_items(self):
        self.shop_list.clear()

        self.shop_items = self.item_manager.get_shop_items()  # 상점 아이템 목록 제공
        for item in self.shop_items:
            price = self.calculate_price(item)
            item_str = f"{item.name} [{item.grade.upper()}] - 💰 {price}G"
            widget = QListWidgetItem(item_str)
            widget.setData(Qt.ItemDataRole.UserRole, item)
            self.shop_list.addItem(widget)

    def refresh_inventory_items(self):
        self.inventory_list.clear()

        for item in self.player.get_inventory():
            price = self.calculate_sell_price(item)
            item_str = f"{item.name} [{item.grade.upper()}] - 판매가 💰 {price}G"
            widget = QListWidgetItem(item_str)
            widget.setData(Qt.ItemDataRole.UserRole, item)
            self.inventory_list.addItem(widget)

    def buy_selected_item(self):
        selected_items = self.shop_list.selectedItems()

        if not selected_items:
            QMessageBox.warning(self, "경고", "구매할 아이템을 선택하세요!")
            return

        item = selected_items[0].data(Qt.ItemDataRole.UserRole)
        price = self.calculate_price(item)

        if self.player.currency < price:
            QMessageBox.warning(self, "구매 실패", "골드가 부족합니다!")
            return

        # 구매 처리
        self.player.currency -= price
        self.player.add_item(item)

        QMessageBox.information(self, "구매 성공", f"{item.name}을(를) 구매했습니다!")
        self.refresh_inventory_items()
        self.game_window.update_status()

    def sell_selected_item(self):
        selected_items = self.inventory_list.selectedItems()

        if not selected_items:
            QMessageBox.warning(self, "경고", "판매할 아이템을 선택하세요!")
            return

        item = selected_items[0].data(Qt.ItemDataRole.UserRole)
        price = self.calculate_sell_price(item)

        # 판매 처리
        self.player.currency += price
        self.player.get_inventory().remove(item)

        QMessageBox.information(self, "판매 성공", f"{item.name}을(를) 판매했습니다!")
        self.refresh_inventory_items()
        self.game_window.update_status()

    def calculate_price(self, item):
        # 등급에 따라 기본 가격 책정
        grade_prices = {
            "normal": 100,
            "rare": 300,
            "epic": 800,
            "legendary": 2000
        }
        return grade_prices.get(item.grade, 100)

    def calculate_sell_price(self, item):
        # 판매가는 구매가의 절반으로 설정
        return self.calculate_price(item) // 2
