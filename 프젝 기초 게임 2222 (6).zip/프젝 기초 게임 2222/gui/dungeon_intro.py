from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QPixmap, QPalette, QBrush

class IntroOverlay(QWidget):
    def __init__(self, parent, on_intro_complete):
        super().__init__(parent)

        self.on_intro_complete = on_intro_complete
        self.setGeometry(0, 0, parent.width(), parent.height())

        # 인트로 텍스트
        self.intro_texts = [
            "혼란과 분열의 시대는 끝났습니다.",
            "오래도록 이어진 끔찍한 전쟁이 막을 내렸습니다.",
            "전쟁이 끝났지만, 당신에게 남은 것은 아무것도 없었습니다.",
            "오랜 전쟁 속에서 약탈과 의뢰로 연명하던 당신.",
            "하지만 그 시절은 끝났습니다.",
            "공포와 굶주림, 죽음과 비명으로 가득했던 이 세상에 평화가 찾아왔습니다.",
            "그러나 당신은 그 어느 때보다 공허했습니다.",
            "국경이 열리고, 왕국은 다시 상업과 교역으로 활기를 되찾았습니다.",
            "그리고 당신 같은 용병은 금방 잊혀졌습니다.",
            "당신이 가진 재화는 금세 바닥이 났습니다.",
            "아니, 사실 이미 오래전에 바닥났을지도 모릅니다.",
            "이제 남은 건... 손끝에서 느껴지는 마지막 남은 금화 한 닢의 차가운 감촉뿐이었습니다.",
            "마지막 남은 금화로 술을 마시던 어느 날, 낡은 술집 구석에서 한 노인이 당신을 바라보며 말을 걸었습니다.",
            "\"북쪽의 숲 너머에 거대한 던전이 있다.\"",
            "노인의 목소리는 마치 바람처럼 나직하고도 음울했습니다.",
            "잔에 남은 술을 홀짝이던 당신이 흘깃 그를 쳐다보자, 그는 말끝을 흐리며 낮게 웃었습니다.",
            "\"그곳엔 평생 써도 남을 금은보화가 숨겨져 있다. 하지만 보물을 손에 넣기 전에... 탐욕이 너를 먼저 집어삼킬 거다.\"",
            "당신은 웃어넘겼습니다. 그러나 노인의 눈빛은 흔들림이 없었습니다.",
            "그의 손가락은 이미 절반 이상 부러져 있었습니다. 마치 무언가를 움켜쥐다가, 부러져버린 것처럼.",
            "선택지는 없었습니다.",
            "그리고 지금. 당신은 이 거대한 던전 앞에 서 있었습니다."
        ]

        self.intro_images = [
            "assets/intro/intro1.png",  # 0번째 문장
            "assets/intro/intro2.png",  # 5번째 문장
            "assets/intro/intro3.png",  # 9번째 문장
            "assets/intro/intro4.png",  # 12번째 문장
            "assets/intro/intro5.png"   # 20번째 문장
        ]

        self.change_points = {
            0: 0,
            5: 1,
            9: 2,
            12: 3,
            20: 4
        }

        self.current_index = 0

        # 레이아웃 세팅
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # 배경 이미지 설정
        self.setAutoFillBackground(True)
        self.update_background(0)  # 첫 배경 이미지

        # 텍스트 라벨
        self.text_label = QLabel("")
        self.text_label.setStyleSheet("color: white; font-size: 18px; padding: 20px; background-color: rgba(0, 0, 0, 150);")
        self.text_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.main_layout.addWidget(self.text_label)

        # 스킵 버튼 생성 및 배치
        self.skip_button = QPushButton("스킵", self)
        self.skip_button.setStyleSheet("""
            QPushButton {
                background-color: rgba(255, 0, 0, 180);
                color: white;
                font-size: 14px;
                padding: 10px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: rgba(255, 50, 50, 200);
            }
        """)
        self.skip_button.resize(80, 40)
        self.skip_button.move(self.width() - 100, 20)
        self.skip_button.clicked.connect(self.finish_intro)

        # 인트로 자동 진행 시작!
        self.start_intro()

    def start_intro(self):
        self.show_next_intro_text()

    def show_next_intro_text(self):
        if self.current_index < len(self.intro_texts):
            self.text_label.setText(self.intro_texts[self.current_index])

            # 배경 전환 타이밍일 때 배경 변경
            if self.current_index in self.change_points:
                image_index = self.change_points[self.current_index]
                self.update_background(image_index)

            self.current_index += 1

            # 텍스트가 계속 넘어가게 타이머 반복 실행
            QTimer.singleShot(3000, self.show_next_intro_text)  # 3초 후에 다음 텍스트
        else:
            self.finish_intro()

    def update_background(self, image_index=0):
        pixmap = QPixmap(self.intro_images[image_index]).scaled(
            self.width(), self.height(), Qt.AspectRatioMode.KeepAspectRatioByExpanding
        )

        palette = self.palette()
        palette.setBrush(QPalette.ColorRole.Window, QBrush(pixmap))
        self.setPalette(palette)

    def finish_intro(self):
        self.hide()
        self.on_intro_complete()

    def resizeEvent(self, event):
        # 창 크기 조정 시 스킵 버튼 위치 재조정
        self.skip_button.move(self.width() - 100, 20)