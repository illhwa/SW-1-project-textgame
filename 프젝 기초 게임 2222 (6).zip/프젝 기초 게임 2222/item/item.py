class Item:
    def __init__(self, name, item_type, stat_changes, description="", grade="normal"):
        self.name = name
        self.item_type = item_type  # weapon, armor, accessory
        self.stat_changes = stat_changes  # {'hp': +10, 'attack': +5}
        self.description = description
        self.grade = grade  # normal, rare, epic, legendary

    def __str__(self):
        return f"[{self.grade.upper()}] {self.name} ({self.item_type}) - {self.description}"

    def get_colored_name(self):
        """아이템 이름을 등급에 따라 색상 처리"""
        grade_colors = {
            "normal": "white",
            "rare": "blue",
            "epic": "purple",
            "legendary": "orange"
        }
        color = grade_colors.get(self.grade, "white")
        return f"<font color='{color}'>[{self.grade.upper()}] {self.name}</font>"
