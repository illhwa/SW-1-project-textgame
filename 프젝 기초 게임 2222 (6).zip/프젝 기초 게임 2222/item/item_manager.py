from item.item import Item
import random

class ItemManager:
    def __init__(self):
        self.item_pool = [
            # normal
            Item("낡은 검", "weapon", {"stamina": +5}, "낡은 검입니다.", grade="normal"),
            Item("가죽 갑옷", "armor", {"hp": +10}, "가볍고 약간의 보호를 제공합니다.", grade="normal"),
            Item("목걸이", "accessory", {"luck": +3}, "별 효과 없는 목걸이입니다.", grade="normal"),

            # rare
            Item("강철 검", "weapon", {"stamina": +10}, "강철로 만들어진 검입니다.", grade="rare"),
            Item("철 갑옷", "armor", {"hp": +20}, "튼튼한 철 갑옷입니다.", grade="rare"),
            Item("행운의 부적", "accessory", {"luck": +7}, "운이 좋아질 것 같은 부적입니다.", grade="rare"),

            # epic
            Item("마검", "weapon", {"stamina": +20, "luck": +5}, "마력이 깃든 검입니다.", grade="epic"),
            Item("용비늘 갑옷", "armor", {"hp": +40}, "드래곤 비늘로 만든 갑옷입니다.", grade="epic"),
            Item("신성한 반지", "accessory", {"luck": +15}, "신성한 힘이 깃든 반지입니다.", grade="epic"),

            # legendary
            Item("신의 검", "weapon", {"stamina": +50, "luck": +20}, "전설의 검입니다.", grade="legendary"),
            Item("불사의 갑옷", "armor", {"hp": +100}, "불사의 힘을 지닌 갑옷입니다.", grade="legendary"),
            Item("운명의 목걸이", "accessory", {"luck": +50}, "운명을 바꿀 수 있는 목걸이입니다.", grade="legendary"),
        ]

    def get_random_item(self):
        # 등급별 드랍 확률
        grade_probabilities = {
            "normal": 0.6,
            "rare": 0.25,
            "epic": 0.1,
            "legendary": 0.05
        }

        grades = list(grade_probabilities.keys())
        probabilities = list(grade_probabilities.values())

        selected_grade = random.choices(grades, probabilities)[0]

        # 해당 등급 아이템 리스트 필터링
        candidates = [item for item in self.item_pool if item.grade == selected_grade]

        return random.choice(candidates)

    def get_shop_items(self):
        return self.item_pool  # 상점에 전체 풀 활용 (추후 필터링 가능)
